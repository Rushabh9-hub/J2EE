package oracaljdbc;
import java.sql.*;
public class Oracaljdbc
{
    public static void main(String[] args) 
    {
          try
          {
               Class.forName("oracle.jdbc.driver.OracleDriver");
               Connection con=DriverManager.getConnection("jdbc:oracle:thin:@127.0.0.1:1521/orcl", "scott", "tiger");
               Statement st=con.createStatement();
               ResultSet rs = st.executeQuery("select * from ora_tab");
               
               while (rs.next()) 
              {                
                  int pid = rs.getInt("pid");
                  String pname = rs.getString("pname");
                  String price = rs.getString("price");
                  
                  System.out.print("product id is:" + pid +",\n");
                  System.out.print("product name is:" + pname +",\n");
                  System.out.print("product price is:" + price +",\n");
                  
              }
              rs.close();
              st.close();
              con.close();
          }
          catch(Exception e) 
          { 
            e.printStackTrace();
          }
    }
    
}
