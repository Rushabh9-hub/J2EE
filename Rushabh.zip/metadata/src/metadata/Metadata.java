package metadata;
import java.sql.*;
public class Metadata 
{
    public static void main(String[] args) 
    {
       try
       {
           DatabaseMetaData dbmd;
           Class.forName("oracle.jdbc.driver.OracleDriver");
           Connection con=DriverManager.getConnection("jdbc:oracle:thin:@127.0.0.1:1521/orcl", "scott", "tiger");
           dbmd=con.getMetaData();
           System.out.print(dbmd.getDatabaseProductName()+ " ,\n");
           System.out.print(dbmd.getDatabaseMinorVersion()+ " ,\n");
           System.out.print(dbmd.getDriverName()+ " ,\n");
           System.out.print(dbmd.getDriverVersion()+ " ,\n");
           System.out.print(dbmd.getUserName()+ " ,\n");
        }
       catch(Exception e)
       {
           System.out.println(e);
       }
    }
    
}
