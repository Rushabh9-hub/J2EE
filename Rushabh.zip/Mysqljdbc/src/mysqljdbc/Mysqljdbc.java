package mysqljdbc;
import java.sql.*;
public class Mysqljdbc
{
    public static void main(String[] args)
    {
        try
        {
          Class.forName("com.mysql.jdbc.Driver");
          
          Connection con = DriverManager.getConnection("jdbc:mysql://localhost/jdbc_1","root","");
          Statement st=con.createStatement();
          ResultSet rs = st.executeQuery("select * from jdbc_tab");
          while(rs.next())
           {
                int id  = rs.getInt("id");
                String Fname = rs.getString("Fname");
                String Lname = rs.getString("Lname");
                String Email = rs.getString("Email");
                
                  //Display values
                System.out.print(" id: " + id +" ,\n");
                System.out.print(" Fname: " + Fname +" ,\n");
                System.out.print(" Lname: " + Lname +",\n");
                System.out.print(" Email: " + Email +",\n");
           }
           rs.close();
           con.close();
        } 
        catch(Exception e)
        {
                e.printStackTrace();
        }
    }
}
